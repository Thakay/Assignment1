Collected data
